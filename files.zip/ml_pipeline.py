"""
============================================================
  ML_PIPELINE.PY  –  Smart Retail Intelligence Engine

  Models trained:
    A. Sales Amount Predictor        (RandomForest Regressor)
    B. Profit Margin Predictor       (GradientBoosting Regressor)
    C. Recommended Sell Qty          (RandomForest Regressor)
    D. High / Low Profit Classifier  (RandomForest Classifier)

  Outputs written to smart_retail_ml/:
    predictions.csv          ← historical fit + model output
    monthly_summary.csv
    yearly_summary.csv
    improvement_report.csv
    feature_importance.csv
    model_scores.csv
    future_predictions.csv   ← NEW: next 6 months forecast
============================================================
"""

import pandas as pd
import numpy as np
import warnings, os
warnings.filterwarnings("ignore")

from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_absolute_error, r2_score, accuracy_score, classification_report

OUT = "smart_retail_ml"
os.makedirs(OUT, exist_ok=True)

# ══════════════════════════════════════════════════════════
# 0. Load master dataset
# ══════════════════════════════════════════════════════════
df = pd.read_csv(f"{OUT}/master_dataset.csv", parse_dates=["Month"])
print(f"✅  Loaded master dataset: {df.shape}")

# ══════════════════════════════════════════════════════════
# 1. Encode categoricals  (store encoders for future use)
# ══════════════════════════════════════════════════════════
encoders = {}
for col in ["Region", "Category", "Weather_Mode", "Seasonality"]:
    le = LabelEncoder()
    df[col + "_enc"] = le.fit_transform(df[col].astype(str))
    encoders[col] = le

# ══════════════════════════════════════════════════════════
# 2. Feature set
# ══════════════════════════════════════════════════════════
FEATURE_COLS = [
    "Region_enc", "Category_enc", "Year", "MonthNum", "Quarter",
    "Avg_Unit_Cost", "Avg_Unit_Price", "Avg_Discount_Sales",
    "Num_Transactions", "New_Customers", "Returning_Customers",
    "Online_Txn", "Retail_Txn",
    "Inventory_Level", "Units_Ordered", "Demand_Forecast",
    "Avg_Discount_Inv", "Holiday_Days", "Competitor_Pricing",
    "Seasonality_enc", "Weather_Mode_enc",
    "Price_vs_Competitor", "Fulfillment_Rate",
    "Recommended_Order_Qty",
]

df_model = df.dropna(subset=FEATURE_COLS + ["Total_Sales_Amount", "Net_Profit_Margin"]).copy()
X = df_model[FEATURE_COLS].fillna(df_model[FEATURE_COLS].median())
scores_log = {}

# ══════════════════════════════════════════════════════════
# 3. MODEL A – Sales Amount Predictor
# ══════════════════════════════════════════════════════════
print("\n── Model A: Sales Amount Predictor ──")
y_sales = df_model["Total_Sales_Amount"]
X_tr, X_te, y_tr, y_te = train_test_split(X, y_sales, test_size=0.2, random_state=42)
rf_sales = RandomForestRegressor(n_estimators=150, max_depth=10, random_state=42, n_jobs=-1)
rf_sales.fit(X_tr, y_tr)
mae_s = mean_absolute_error(y_te, rf_sales.predict(X_te))
r2_s  = r2_score(y_te, rf_sales.predict(X_te))
cv_s  = cross_val_score(rf_sales, X, y_sales, cv=5, scoring="r2").mean()
print(f"  MAE: {mae_s:,.2f}  |  R²: {r2_s:.4f}  |  CV R²: {cv_s:.4f}")
scores_log["Sales_Amount"] = {"MAE": round(mae_s, 2), "R2": round(r2_s, 4), "CV_R2": round(cv_s, 4)}

# ══════════════════════════════════════════════════════════
# 4. MODEL B – Profit Margin Predictor
# ══════════════════════════════════════════════════════════
print("\n── Model B: Profit Margin Predictor ──")
y_margin = df_model["Net_Profit_Margin"]
X_tr2, X_te2, y_tr2, y_te2 = train_test_split(X, y_margin, test_size=0.2, random_state=42)
gb_margin = GradientBoostingRegressor(n_estimators=200, learning_rate=0.08, max_depth=4, random_state=42)
gb_margin.fit(X_tr2, y_tr2)
mae_m = mean_absolute_error(y_te2, gb_margin.predict(X_te2))
r2_m  = r2_score(y_te2, gb_margin.predict(X_te2))
cv_m  = cross_val_score(gb_margin, X, y_margin, cv=5, scoring="r2").mean()
print(f"  MAE: {mae_m:.2f}%  |  R²: {r2_m:.4f}  |  CV R²: {cv_m:.4f}")
scores_log["Profit_Margin"] = {"MAE": round(mae_m, 4), "R2": round(r2_m, 4), "CV_R2": round(cv_m, 4)}

# ══════════════════════════════════════════════════════════
# 5. MODEL C – Sell Quantity Predictor
# ══════════════════════════════════════════════════════════
print("\n── Model C: Sell Quantity Predictor ──")
y_qty = df_model["Total_Qty_Sold"]
X_tr3, X_te3, y_tr3, y_te3 = train_test_split(X, y_qty, test_size=0.2, random_state=42)
rf_qty = RandomForestRegressor(n_estimators=150, max_depth=8, random_state=42, n_jobs=-1)
rf_qty.fit(X_tr3, y_tr3)
mae_q = mean_absolute_error(y_te3, rf_qty.predict(X_te3))
r2_q  = r2_score(y_te3, rf_qty.predict(X_te3))
cv_q  = cross_val_score(rf_qty, X, y_qty, cv=5, scoring="r2").mean()
print(f"  MAE: {mae_q:.2f} units  |  R²: {r2_q:.4f}  |  CV R²: {cv_q:.4f}")
scores_log["Sell_Quantity"] = {"MAE": round(mae_q, 2), "R2": round(r2_q, 4), "CV_R2": round(cv_q, 4)}

# ══════════════════════════════════════════════════════════
# 6. MODEL D – Profit Classifier
# ══════════════════════════════════════════════════════════
print("\n── Model D: Profit Classifier ──")
threshold = df_model["Net_Profit_Margin"].median()
df_model["Profit_Class"] = (df_model["Net_Profit_Margin"] >= threshold).astype(int)
y_cls = df_model["Profit_Class"]
X_tr4, X_te4, y_tr4, y_te4 = train_test_split(X, y_cls, test_size=0.2, random_state=42)
rf_cls = RandomForestClassifier(n_estimators=150, max_depth=8, random_state=42, n_jobs=-1)
rf_cls.fit(X_tr4, y_tr4)
acc = accuracy_score(y_te4, rf_cls.predict(X_te4))
print(f"  Accuracy: {acc:.4f}")
print(classification_report(y_te4, rf_cls.predict(X_te4), target_names=["Low Profit", "High Profit"]))
scores_log["Profit_Classifier"] = {"Accuracy": round(acc, 4)}

# ══════════════════════════════════════════════════════════
# 7. Historical predictions on full dataset
# ══════════════════════════════════════════════════════════
X_full = df_model[FEATURE_COLS].fillna(df_model[FEATURE_COLS].median())
df_model["Predicted_Sales"]        = rf_sales.predict(X_full)
df_model["Predicted_Margin_Pct"]   = gb_margin.predict(X_full)
df_model["Predicted_Sell_Qty"]     = rf_qty.predict(X_full).round().astype(int)
df_model["Predicted_Profit_Class"] = pd.Series(
    rf_cls.predict(X_full), index=df_model.index
).map({1: "High Profit", 0: "Low Profit"})
df_model["Predicted_Gross_Profit"]   = df_model["Predicted_Sales"] * (df_model["Predicted_Margin_Pct"] / 100)
df_model["Predicted_Transport_Cost"] = df_model["Avg_Unit_Cost"] * df_model["Predicted_Sell_Qty"] * 0.02
df_model["Predicted_Net_Profit"]     = df_model["Predicted_Gross_Profit"] - df_model["Predicted_Transport_Cost"]

# ══════════════════════════════════════════════════════════
# 8. Monthly & Yearly summaries
# ══════════════════════════════════════════════════════════
monthly = (
    df_model.groupby(["Year", "MonthNum", "Region", "Category"])
    .agg(
        Monthly_Sales    = ("Total_Sales_Amount",  "sum"),
        Monthly_Profit   = ("Net_Profit",          "sum"),
        Monthly_Qty      = ("Total_Qty_Sold",      "sum"),
        Avg_Margin_Pct   = ("Net_Profit_Margin",   "mean"),
        Spot_Txn         = ("Retail_Txn",          "sum"),
        Online_Txn_Count = ("Online_Txn",          "sum"),
        Transport_Cost   = ("Transport_Cost_Est",  "sum"),
        Pred_Sales       = ("Predicted_Sales",     "sum"),
        Pred_Profit      = ("Predicted_Net_Profit","sum"),
    )
    .reset_index()
)

yearly = (
    df_model.groupby(["Year", "Region", "Category"])
    .agg(
        Yearly_Sales     = ("Total_Sales_Amount", "sum"),
        Yearly_Profit    = ("Net_Profit",         "sum"),
        Yearly_Qty       = ("Total_Qty_Sold",     "sum"),
        Avg_Margin_Pct   = ("Net_Profit_Margin",  "mean"),
        Total_Transport  = ("Transport_Cost_Est", "sum"),
        Spot_Txn         = ("Retail_Txn",         "sum"),
        Online_Txn_Count = ("Online_Txn",         "sum"),
    )
    .reset_index()
)

# ══════════════════════════════════════════════════════════
# 9. Improvement Opportunities Report
# ══════════════════════════════════════════════════════════
insights = []
for (region, cat), grp in df_model.groupby(["Region", "Category"]):
    row = {"Region": region, "Category": cat}
    avg_margin  = grp["Net_Profit_Margin"].mean()
    best_margin = df_model["Net_Profit_Margin"].quantile(0.75)
    row["Avg_Margin_Pct"]               = round(avg_margin, 2)
    row["Margin_Gap_vs_Top_Quartile"]   = round(best_margin - avg_margin, 2)
    row["Avg_Discount_Pct"]             = round(grp["Avg_Discount_Sales"].mean() * 100, 2)
    row["Avg_Price_vs_Competitor"]      = round(grp["Price_vs_Competitor"].mean(), 2)
    row["Avg_Inventory_Coverage_Days"]  = round(grp["Inventory_Coverage"].mean(), 1)
    row["Spot_Sales_Ratio_Avg"]         = round(grp["Spot_Sales_Ratio"].mean() * 100, 2)
    row["Online_Sales_Ratio_Avg"]       = round(grp["Online_Sales_Ratio"].mean() * 100, 2)
    row["Fulfillment_Rate_Avg"]         = round(grp["Fulfillment_Rate"].mean() * 100, 2)
    tips = []
    if row["Margin_Gap_vs_Top_Quartile"] > 5:
        tips.append(f"Margin {row['Margin_Gap_vs_Top_Quartile']:.1f}pp below top performers — review pricing or costs.")
    if row["Avg_Discount_Pct"] > 20:
        tips.append(f"High discount ({row['Avg_Discount_Pct']:.1f}%) — switch to loyalty rewards.")
    if row["Avg_Price_vs_Competitor"] < -5:
        tips.append("Priced below competitors — room to raise prices.")
    if row["Avg_Inventory_Coverage_Days"] > 60:
        tips.append("Over-stocked (>60 days) — reduce order qty to free capital.")
    if row["Avg_Inventory_Coverage_Days"] < 10:
        tips.append("Under-stocked (<10 days) — increase reorder frequency.")
    if row["Fulfillment_Rate_Avg"] < 70:
        tips.append("Low demand fulfilment — stock more to capture latent demand.")
    if row["Online_Sales_Ratio_Avg"] < 20:
        tips.append("Low online share — invest in e-commerce presence.")
    row["Recommendations"] = " | ".join(tips) if tips else "Performance is on-track."
    insights.append(row)

improvement_df = pd.DataFrame(insights)

# ══════════════════════════════════════════════════════════
# 10. Feature Importance
# ══════════════════════════════════════════════════════════
fi_df = pd.DataFrame({
    "Feature":           FEATURE_COLS,
    "Importance_Sales":  rf_sales.feature_importances_,
    "Importance_Margin": gb_margin.feature_importances_,
    "Importance_Qty":    rf_qty.feature_importances_,
    "Importance_Cls":    rf_cls.feature_importances_,
}).sort_values("Importance_Sales", ascending=False)

# ══════════════════════════════════════════════════════════
# 11. FUTURE PREDICTIONS  (next 6 months from last date)
# ══════════════════════════════════════════════════════════
print("\n── Future Predictions: next 6 months ──")

last_month = df_model["Month"].max()
regions    = df_model["Region"].unique()
categories = df_model["Category"].unique()

# Per-segment rolling averages used to fill forward feature values
seg_stats = (
    df_model.groupby(["Region", "Category"])
    .agg(
        Avg_Unit_Cost      = ("Avg_Unit_Cost",      "mean"),
        Avg_Unit_Price     = ("Avg_Unit_Price",     "mean"),
        Avg_Discount_Sales = ("Avg_Discount_Sales", "mean"),
        Num_Transactions   = ("Num_Transactions",   "mean"),
        New_Customers      = ("New_Customers",      "mean"),
        Returning_Customers= ("Returning_Customers","mean"),
        Online_Txn         = ("Online_Txn",         "mean"),
        Retail_Txn         = ("Retail_Txn",         "mean"),
        Inventory_Level    = ("Inventory_Level",    "mean"),
        Units_Ordered      = ("Units_Ordered",      "mean"),
        Demand_Forecast    = ("Demand_Forecast",    "mean"),
        Avg_Discount_Inv   = ("Avg_Discount_Inv",   "mean"),
        Holiday_Days       = ("Holiday_Days",       "mean"),
        Competitor_Pricing = ("Competitor_Pricing", "mean"),
        Price_vs_Competitor= ("Price_vs_Competitor","mean"),
        Fulfillment_Rate   = ("Fulfillment_Rate",   "mean"),
        Recommended_Order_Qty = ("Recommended_Order_Qty", "mean"),
    )
    .reset_index()
)

# Seasonality / weather: use same month from prior year
season_map = (
    df_model.groupby(["Region", "Category", "MonthNum"])
    .agg(
        Seasonality  = ("Seasonality",  lambda x: x.mode().iloc[0]),
        Weather_Mode = ("Weather_Mode", lambda x: x.mode().iloc[0]),
    )
    .reset_index()
)

future_rows = []
for i in range(1, 7):                          # 6 months ahead
    future_month = last_month + pd.DateOffset(months=i)
    month_num    = future_month.month
    year         = future_month.year
    quarter      = (month_num - 1) // 3 + 1

    for region in regions:
        for category in categories:
            seg = seg_stats[
                (seg_stats["Region"] == region) &
                (seg_stats["Category"] == category)
            ]
            if seg.empty:
                continue
            seg = seg.iloc[0]

            sm = season_map[
                (season_map["Region"] == region) &
                (season_map["Category"] == category) &
                (season_map["MonthNum"] == month_num)
            ]
            seasonality  = sm["Seasonality"].iloc[0]  if not sm.empty else "Summer"
            weather_mode = sm["Weather_Mode"].iloc[0] if not sm.empty else "Sunny"

            region_enc   = encoders["Region"].transform([region])[0]
            category_enc = encoders["Category"].transform([category])[0]
            season_enc   = encoders["Seasonality"].transform([seasonality])[0]
            weather_enc  = encoders["Weather_Mode"].transform([weather_mode])[0]

            row_feat = {
                "Region_enc":          region_enc,
                "Category_enc":        category_enc,
                "Year":                year,
                "MonthNum":            month_num,
                "Quarter":             quarter,
                "Avg_Unit_Cost":       seg["Avg_Unit_Cost"],
                "Avg_Unit_Price":      seg["Avg_Unit_Price"],
                "Avg_Discount_Sales":  seg["Avg_Discount_Sales"],
                "Num_Transactions":    seg["Num_Transactions"],
                "New_Customers":       seg["New_Customers"],
                "Returning_Customers": seg["Returning_Customers"],
                "Online_Txn":          seg["Online_Txn"],
                "Retail_Txn":          seg["Retail_Txn"],
                "Inventory_Level":     seg["Inventory_Level"],
                "Units_Ordered":       seg["Units_Ordered"],
                "Demand_Forecast":     seg["Demand_Forecast"],
                "Avg_Discount_Inv":    seg["Avg_Discount_Inv"],
                "Holiday_Days":        seg["Holiday_Days"],
                "Competitor_Pricing":  seg["Competitor_Pricing"],
                "Seasonality_enc":     season_enc,
                "Weather_Mode_enc":    weather_enc,
                "Price_vs_Competitor": seg["Price_vs_Competitor"],
                "Fulfillment_Rate":    seg["Fulfillment_Rate"],
                "Recommended_Order_Qty": seg["Recommended_Order_Qty"],
            }

            future_rows.append({
                "Future_Month": future_month.strftime("%Y-%m"),
                "Region":       region,
                "Category":     category,
                **row_feat,
            })

future_df = pd.DataFrame(future_rows)
X_future  = future_df[FEATURE_COLS].fillna(0)

future_df["Predicted_Sales"]        = rf_sales.predict(X_future).round(2)
future_df["Predicted_Margin_Pct"]   = gb_margin.predict(X_future).round(2)
future_df["Predicted_Sell_Qty"]     = rf_qty.predict(X_future).round().astype(int)
future_df["Predicted_Profit_Class"] = pd.Series(
    rf_cls.predict(X_future)
).map({1: "High Profit", 0: "Low Profit"}).values

future_df["Predicted_Gross_Profit"]   = (future_df["Predicted_Sales"] * future_df["Predicted_Margin_Pct"] / 100).round(2)
future_df["Predicted_Transport_Cost"] = (future_df["Avg_Unit_Cost"] * future_df["Predicted_Sell_Qty"] * 0.02).round(2)
future_df["Predicted_Net_Profit"]     = (future_df["Predicted_Gross_Profit"] - future_df["Predicted_Transport_Cost"]).round(2)
future_df["Recommended_Price"]        = (future_df["Avg_Unit_Cost"] * 1.40).round(2)
future_df["Recommended_Stock_Order"]  = (future_df["Demand_Forecast"] * 1.15).round().astype(int)

FUTURE_COLS = [
    "Future_Month", "Region", "Category",
    "Predicted_Sales", "Predicted_Sell_Qty",
    "Predicted_Margin_Pct", "Predicted_Gross_Profit",
    "Predicted_Transport_Cost", "Predicted_Net_Profit",
    "Predicted_Profit_Class",
    "Recommended_Price", "Recommended_Stock_Order",
    "Demand_Forecast", "Competitor_Pricing",
]

print(future_df[["Future_Month","Region","Category",
                 "Predicted_Sales","Predicted_Net_Profit",
                 "Predicted_Profit_Class"]].to_string(index=False))

# ══════════════════════════════════════════════════════════
# 12. Save all outputs
# ══════════════════════════════════════════════════════════
PRED_COLS = [
    "Month", "Region", "Category",
    "Total_Sales_Amount", "Total_Qty_Sold",
    "Avg_Unit_Cost", "Avg_Unit_Price",
    "Gross_Profit", "Transport_Cost_Est", "Net_Profit",
    "Net_Profit_Margin", "Profit_Margin_Pct",
    "Spot_Sales_Ratio", "Online_Sales_Ratio",
    "Inventory_Level", "Inventory_Coverage",
    "Demand_Forecast", "Recommended_Price", "Recommended_Order_Qty",
    "Predicted_Sales", "Predicted_Margin_Pct",
    "Predicted_Sell_Qty", "Predicted_Net_Profit",
    "Predicted_Profit_Class",
    "Sales_Growth_MoM", "Profit_Growth_MoM",
    "Fulfillment_Rate",
]

df_model[PRED_COLS].to_csv(f"{OUT}/predictions.csv",            index=False)
monthly.to_csv(f"{OUT}/monthly_summary.csv",                    index=False)
yearly.to_csv(f"{OUT}/yearly_summary.csv",                      index=False)
improvement_df.to_csv(f"{OUT}/improvement_report.csv",          index=False)
fi_df.to_csv(f"{OUT}/feature_importance.csv",                   index=False)
pd.DataFrame(scores_log).T.to_csv(f"{OUT}/model_scores.csv")
future_df[FUTURE_COLS].to_csv(f"{OUT}/future_predictions.csv",  index=False)

print("\n✅  All outputs saved to smart_retail_ml/:")
for f in ["predictions.csv", "monthly_summary.csv", "yearly_summary.csv",
          "improvement_report.csv", "feature_importance.csv",
          "model_scores.csv", "future_predictions.csv"]:
    print(f"   {f}")
