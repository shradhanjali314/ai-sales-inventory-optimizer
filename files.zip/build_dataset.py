"""
============================================================
  BUILD_DATASET.PY  –  Smart Retail Master Dataset Builder
  Merges sales_data.csv + retail_store_inventory.csv and
  engineers all features needed by the ML pipeline.

  Expected project layout (run from project root):
    sales_data.csv
    retail_store_inventory.csv
    build_dataset.py
    ml_pipeline.py
    smart_retail_ml/   ← outputs land here
============================================================
"""

import pandas as pd
import numpy as np
import os, warnings
warnings.filterwarnings("ignore")

# ── 1. Load raw data ──────────────────────────────────────
sales = pd.read_csv("sales_data.csv", parse_dates=["Sale_Date"])
inv   = pd.read_csv("retail_store_inventory.csv", parse_dates=["Date"])

# Normalise category names so they match across both files
cat_map = {"Groceries": "Food"}
inv["Category"] = inv["Category"].replace(cat_map)

# ── 2. Aggregate inventory to (Date, Region, Category) ───
inv_agg = (
    inv.groupby([inv["Date"].dt.to_period("M").dt.to_timestamp(), "Region", "Category"])
    .agg(
        Inventory_Level    = ("Inventory Level",    "mean"),
        Units_Sold_Online  = ("Units Sold",         "sum"),
        Units_Ordered      = ("Units Ordered",      "sum"),
        Demand_Forecast    = ("Demand Forecast",    "mean"),
        Avg_Price          = ("Price",              "mean"),
        Avg_Discount_Inv   = ("Discount",           "mean"),
        Weather_Mode       = ("Weather Condition",  lambda x: x.mode().iloc[0]),
        Holiday_Days       = ("Holiday/Promotion",  "sum"),
        Competitor_Pricing = ("Competitor Pricing", "mean"),
        Seasonality        = ("Seasonality",        lambda x: x.mode().iloc[0]),
    )
    .reset_index()
    .rename(columns={"Date": "Month"})
)

# ── 3. Prepare sales data ─────────────────────────────────
sales["Month"] = sales["Sale_Date"].dt.to_period("M").dt.to_timestamp()
sales_agg = (
    sales.groupby(["Month", "Region", "Product_Category"])
    .agg(
        Total_Sales_Amount  = ("Sales_Amount",  "sum"),
        Total_Qty_Sold      = ("Quantity_Sold", "sum"),
        Avg_Unit_Cost       = ("Unit_Cost",     "mean"),
        Avg_Unit_Price      = ("Unit_Price",    "mean"),
        Avg_Discount_Sales  = ("Discount",      "mean"),
        Num_Transactions    = ("Product_ID",    "count"),
        New_Customers       = ("Customer_Type", lambda x: (x == "New").sum()),
        Returning_Customers = ("Customer_Type", lambda x: (x == "Returning").sum()),
        Online_Txn          = ("Sales_Channel", lambda x: (x == "Online").sum()),
        Retail_Txn          = ("Sales_Channel", lambda x: (x == "Retail").sum()),
    )
    .reset_index()
    .rename(columns={"Product_Category": "Category"})
)

# ── 4. Merge ──────────────────────────────────────────────
df = sales_agg.merge(inv_agg, on=["Month", "Region", "Category"], how="left")

# ── 5. Feature Engineering ────────────────────────────────
# NOTE: Unit_Cost / Unit_Price in sales_data are per-TRANSACTION totals, not per-unit.
df["Gross_Profit"]          = df["Total_Sales_Amount"] - (df["Avg_Unit_Cost"] * df["Num_Transactions"])
df["Profit_Margin_Pct"]     = (df["Gross_Profit"] / df["Total_Sales_Amount"].replace(0, np.nan)) * 100
df["Avg_Revenue_Per_Txn"]   = df["Total_Sales_Amount"] / df["Num_Transactions"].replace(0, np.nan)
df["Transport_Cost_Est"]    = df["Avg_Unit_Cost"] * df["Num_Transactions"] * 0.02
df["Net_Profit"]            = df["Gross_Profit"] - df["Transport_Cost_Est"]
df["Net_Profit_Margin"]     = (df["Net_Profit"] / df["Total_Sales_Amount"].replace(0, np.nan)) * 100
df["Spot_Sales_Ratio"]      = df["Retail_Txn"] / df["Num_Transactions"].replace(0, np.nan)
df["Online_Sales_Ratio"]    = df["Online_Txn"] / df["Num_Transactions"].replace(0, np.nan)
df["Price_vs_Competitor"]   = df["Avg_Unit_Price"] - df["Competitor_Pricing"].fillna(df["Avg_Unit_Price"])
df["Fulfillment_Rate"]      = (df["Units_Sold_Online"] / df["Demand_Forecast"].replace(0, np.nan)).clip(0, 1)
df["Inventory_Coverage"]    = df["Inventory_Level"] / (df["Total_Qty_Sold"] / 30).replace(0, np.nan)
df["Year"]                  = df["Month"].dt.year
df["MonthNum"]              = df["Month"].dt.month
df["Quarter"]               = df["Month"].dt.quarter
df["Recommended_Price"]     = df["Avg_Unit_Cost"] * 1.40
df["Recommended_Order_Qty"] = (df["Demand_Forecast"] * 1.15).round().fillna(df["Units_Ordered"])

df = df.sort_values(["Region", "Category", "Month"])
df["Sales_Growth_MoM"]  = df.groupby(["Region", "Category"])["Total_Sales_Amount"].pct_change() * 100
df["Profit_Growth_MoM"] = df.groupby(["Region", "Category"])["Net_Profit"].pct_change() * 100

# ── 6. Save ───────────────────────────────────────────────
os.makedirs("smart_retail_ml", exist_ok=True)
out = "smart_retail_ml/master_dataset.csv"
df.to_csv(out, index=False)
print(f"✅  master_dataset.csv saved  |  shape: {df.shape}")
